package io.boostgaurdian

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TelegramClient(private val token: String) {
    suspend fun sendMessage(chatId: String, text: String): Boolean = withContext(Dispatchers.IO) {
        if (token.isBlank() || chatId.isBlank()) return@withContext false
        val url = URL("https://api.telegram.org/bot$token/sendMessage")
        val body = "chat_id=${URLEncoder.encode(chatId, "UTF-8")}" +
                "&text=${URLEncoder.encode(text, "UTF-8")}"

        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.outputStream.use { it.write(body.toByteArray()) }
        c.responseCode in 200..299
    }
}
