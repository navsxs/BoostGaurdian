package io.boostgaurdian

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationBridge : NotificationListenerService() {
    companion object {
        @Volatile var activeCount: Int = 0
            private set
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        activeCount++
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        activeCount = (activeCount - 1).coerceAtLeast(0)
    }
}
