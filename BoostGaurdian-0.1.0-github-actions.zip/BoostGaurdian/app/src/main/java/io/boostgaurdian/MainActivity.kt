package io.boostgaurdian

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = AppPrefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "BoostGaurdian"
            textSize = 28f
        }
        root.addView(title)

        root.addView(TextView(this).apply {
            text = "Transparent remote administration • foreground notification always visible"
        })

        val token = EditText(this).apply {
            hint = "Telegram bot token"
            setText(prefs.botToken)
        }
        root.addView(token)

        val admin = EditText(this).apply {
            hint = "Authorized Telegram user/chat ID"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(prefs.adminUserId)
        }
        root.addView(admin)

        val boot = CheckBox(this).apply {
            text = "Start at boot"
            isChecked = prefs.startOnBoot
        }
        root.addView(boot)

        val enabled = CheckBox(this).apply {
            text = "Enable BoostGaurdian"
            isChecked = prefs.enabled
        }
        root.addView(enabled)

        val save = Button(this).apply { text = "Save settings & start" }
        root.addView(save)

        val notifications = Button(this).apply { text = "Open notification access settings" }
        root.addView(notifications)

        root.addView(TextView(this).apply {
            text = "\nMVP safety boundary:\n" +
                    "Telegram control is limited to non-sensitive administration. " +
                    "Remote SMS/call-log retrieval and remote camera, microphone, " +
                    "screenshot, and screen-recording commands are deliberately not included."
        })

        save.setOnClickListener {
            prefs.botToken = token.text.toString().trim()
            prefs.adminUserId = admin.text.toString().trim()
            prefs.startOnBoot = boot.isChecked
            prefs.enabled = enabled.isChecked

            if (Build.VERSION.SDK_INT >= 33) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }

            if (prefs.enabled) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, GuardianService::class.java)
                )
            } else {
                stopService(Intent(this, GuardianService::class.java))
            }
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }

        notifications.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        setContentView(root)
    }
}
