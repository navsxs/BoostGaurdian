package io.boostgaurdian

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.BatteryManager
import android.os.Build
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.text.DateFormat
import java.util.Date

class GuardianService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var prefs: AppPrefs

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        createChannel()

        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentTitle("BoostGaurdian is running")
            .setContentText("Transparent remote administration is active")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()

        startForeground(NOTIFICATION_ID, notification)
        scope.launch { pollTelegram() }
    }

    private suspend fun pollTelegram() {
        // Intentionally limited MVP command set:
        // /status and /help. Sensitive acquisition commands are not implemented.
        while (isActive && prefs.enabled) {
            delay(5000)
            // A production version should use Telegram getUpdates with a persisted
            // update offset and strict admin-user-ID checking.
            // This starter deliberately avoids implementing remote acquisition
            // of SMS, call logs, screen, camera, or microphone data.
        }
    }

    fun deviceStatus(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(n)
        val transport = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            else -> "Offline/unknown"
        }
        val now = DateFormat.getDateTimeInstance().format(Date())
        return "BoostGaurdian status\nTime: $now\nBattery: $level%\nNetwork: $transport"
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.channel_description)
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "boostgaurdian_service"
        private const val NOTIFICATION_ID = 41001
    }
}
