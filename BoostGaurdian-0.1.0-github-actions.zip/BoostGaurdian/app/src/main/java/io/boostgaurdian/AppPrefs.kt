package io.boostgaurdian

import android.content.Context

class AppPrefs(context: Context) {
    private val p = context.getSharedPreferences("boostgaurdian", Context.MODE_PRIVATE)

    var botToken: String
        get() = p.getString("bot_token", "") ?: ""
        set(v) = p.edit().putString("bot_token", v).apply()

    var adminUserId: String
        get() = p.getString("admin_user_id", "") ?: ""
        set(v) = p.edit().putString("admin_user_id", v).apply()

    var startOnBoot: Boolean
        get() = p.getBoolean("start_on_boot", false)
        set(v) = p.edit().putBoolean("start_on_boot", v).apply()

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) = p.edit().putBoolean("enabled", v).apply()
}
